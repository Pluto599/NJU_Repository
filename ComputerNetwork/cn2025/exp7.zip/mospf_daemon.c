#include "include/mospf_daemon.h"
#include "include/mospf_proto.h"
#include "include/mospf_nbr.h"
#include "include/mospf_database.h"

#include "include/ip.h"
#include "include/rtable.h"
#include "include/list.h"
#include "include/log.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <limits.h>

extern ustack_t *instance;

pthread_mutex_t mospf_lock;
#define MINE_DEBUG_MODE

void mprint_lsdb(){
#ifdef MINE_DEBUG_MODE
	log(DEBUG, "print_lsdb called");
	fprintf(stderr, "LSDB:\n");
	fprintf(stderr, "node_rid\tnetwork\tmask\tlinked_rid\tseq\n");
	fprintf(stderr, "--------------------------------------\n");
	mospf_db_entry_t* lsas;
	list_for_each_entry(lsas, &mospf_db, list){
		for (int i = 0; i < lsas->nadv; ++i){
			fprintf(stderr, "%x\t"IP_FMT"\t"IP_FMT"\t%x\t%d\n", lsas->rid, HOST_IP_FMT_STR(lsas->array[i].network), HOST_IP_FMT_STR(lsas->array[i].mask), lsas->array[i].rid, lsas->seq);
		}
		fprintf(stderr, "--------------------------------------\n");
	}
	fflush(stderr);
#endif
}
void mprint_rtable()
{
	#ifdef MINE_DEBUG_MODE
	// Print the routing table
	fprintf(stderr, "Routing Table:\n");
	fprintf(stderr, "dest\tmask\tgateway\tif_name\n");
	fprintf(stderr, "--------------------------------------\n");
	rt_entry_t *entry = NULL;

	// pthread_mutex_lock(&rt_lock);

	list_for_each_entry(entry, &rtable, list) {
		fprintf(stderr, IP_FMT"\t"IP_FMT"\t"IP_FMT"\t%s\n", \
				HOST_IP_FMT_STR(entry->dest), \
				HOST_IP_FMT_STR(entry->mask), \
				HOST_IP_FMT_STR(entry->gw), \
				entry->if_name);
	}

	// pthread_mutex_unlock(&rt_lock);

	fprintf(stderr, "--------------------------------------\n");
	#endif
}

void mospf_init()
{
    pthread_mutex_init(&mospf_lock, NULL);

    instance->area_id = 0;
    // get the ip address of the first interface
    iface_info_t *iface = list_entry(instance->iface_list.next, iface_info_t, list);
    instance->router_id = iface->ip;
    instance->sequence_num = 0;
    instance->lsuint = MOSPF_DEFAULT_LSUINT;

    iface = NULL;
    list_for_each_entry(iface, &instance->iface_list, list) {
        iface->helloint = MOSPF_DEFAULT_HELLOINT;
        init_list_head(&iface->nbr_list);
    }

    init_mospf_db();

    // 将自己添加到LSU中
    mospf_db_entry_t *self_lsu = malloc(sizeof(mospf_db_entry_t));
    list_add_tail(&self_lsu->list, &mospf_db);
    self_lsu->rid = instance->router_id;
    self_lsu->seq = 0;
    self_lsu->nadv = 1;
    self_lsu->alive = 0;
    self_lsu->array = malloc(sizeof(struct mospf_lsa) * 8);
    iface_info_t *self_router = list_entry(instance->iface_list.next, iface_info_t, list);
    self_lsu->array[0].network = self_router->ip;
    self_lsu->array[0].mask = self_router->mask;
    self_lsu->array[0].rid = instance->router_id;

    // 扫描路由表，将直接连接的网络添加到LSU中
    pthread_mutex_lock(&rt_lock);
    rt_entry_t *entry;
        list_for_each_entry(entry, &rtable, list) {
        if (entry->gw == 0)
        {
            self_lsu->array[self_lsu->nadv].network = entry->dest;
            self_lsu->array[self_lsu->nadv].mask = entry->mask;
            self_lsu->array[self_lsu->nadv].rid = 0;
            self_lsu->nadv++;
        }
    }
    pthread_mutex_unlock(&rt_lock);
}

void *sending_mospf_hello_thread(void *param);
void *sending_mospf_lsu_thread(void *param);
void *checking_nbr_thread(void *param);
void *checking_database_thread(void *param);

void mospf_run()
{
	pthread_t hello, lsu, nbr, db;
	pthread_create(&hello, NULL, sending_mospf_hello_thread, NULL);
	pthread_create(&lsu, NULL, sending_mospf_lsu_thread, NULL);
	pthread_create(&nbr, NULL, checking_nbr_thread, NULL);
	pthread_create(&db, NULL, checking_database_thread, NULL);
}

void *sending_mospf_hello_thread(void *param)
{
	// fprintf(stdout, "TODO: send mOSPF Hello message periodically.\n");
    while (1)
    {
        log(DEBUG, "router [%x] begin to send hello", instance->router_id);
        pthread_mutex_lock(&mospf_lock);
        // 准备发送的包
        int size = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + MOSPF_HDR_SIZE + MOSPF_HELLO_SIZE;
        uint8_t dstMAC[ETH_ALEN] = {0x01, 0x00, 0x5E, 0x00, 0x00, 0x05};
        iface_info_t *iface = NULL;
        list_for_each_entry(iface, &instance->iface_list, list) 
        {
            char* packet = malloc(size);
            if (packet == NULL) {
                log(ERROR, "malloc failed");
                pthread_mutex_unlock(&mospf_lock);
                return NULL;
            }
            // 初始化mospf头
            struct mospf_hdr *mospf = (struct mospf_hdr *)(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE);
            mospf_init_hdr(mospf, MOSPF_TYPE_HELLO, MOSPF_HDR_SIZE + MOSPF_HELLO_SIZE,
				instance->router_id, instance->area_id);
            
            // 初始化Hello消息
            struct mospf_hello *hello = (struct mospf_hello *)((char *)mospf + MOSPF_HDR_SIZE);
            mospf_init_hello(hello, iface->mask);
            mospf->checksum = mospf_checksum(mospf);

            // 设置以太网头
            struct ether_header *eh = (struct ether_header *)packet;
            memcpy(eh->ether_shost, iface->mac, ETH_ALEN);
            memcpy(eh->ether_dhost, dstMAC, ETH_ALEN);
            eh->ether_type = htons(ETH_P_IP);

            // 设置IP头
            struct iphdr *ip = (struct iphdr *)(packet + ETHER_HDR_SIZE);
			ip_init_hdr(ip, iface->ip, MOSPF_ALLSPFRouters, size - ETHER_HDR_SIZE, IPPROTO_MOSPF);
            ip->ttl = 1;

            // 发送包
            iface_send_packet(iface, packet, size);
        }
        pthread_mutex_unlock(&mospf_lock);
        log(DEBUG, "router [%x] sent hello finished", instance->router_id);
        sleep(3);
        // sleep(MOSPF_DEFAULT_HELLOINT);
    }
	return NULL;
}

void *checking_nbr_thread(void *param)
{
	// fprintf(stdout, "TODO: neighbor list timeout operation.\n");
    while (1)
    {
        pthread_mutex_lock(&mospf_lock);
        log(DEBUG, "router [%x] checking neighbors", instance->router_id);
        iface_info_t *iface = NULL, *pre = NULL;
        list_for_each_entry_safe(iface, pre, &instance->iface_list, list) 
        {
            mospf_nbr_t *nbr = NULL, *pre_nbr = NULL;
            list_for_each_entry_safe(nbr, pre_nbr, &iface->nbr_list, list) 
            {
                if (time(NULL) - nbr->alive >= MOSPF_HELLO_TIMEOUT) 
                {
                    // 超时，删除邻居
                    list_delete_entry(&nbr->list);
                    // 从自己的LSU中删除邻居的LSA
                    mospf_db_entry_t *self_lsu = NULL;
                    list_for_each_entry(self_lsu, &mospf_db, list)
                    {
                        if (self_lsu->rid == instance->router_id) 
                        {
                            for (int i = 0; i < self_lsu->nadv; i++) {
                                if (self_lsu->array[i].rid == nbr->nbr_id) {
                                    for (int j = i; j < self_lsu->nadv - 1; j++) {
                                        self_lsu->array[j] = self_lsu->array[j + 1];
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    // 更新LSU的邻接表
                    mospf_db_entry_t *nbr_lsu = NULL;
                    list_for_each_entry(nbr_lsu, &mospf_db, list) {
						if (nbr_lsu->rid == nbr->nbr_id) {
							list_delete_entry(&nbr_lsu->list);
                            free(nbr_lsu->array);
                            free(nbr_lsu);
                            break;
                        }
                    }
                    free(nbr);
                }
            }
        }
        update_rtable_from_lsu();
        mospf_send_lsu(0);
        pthread_mutex_unlock(&mospf_lock);
        sleep(5);
    }


	return NULL;
}

void *checking_database_thread(void *param)
{
	// fprintf(stdout, "TODO: link state database timeout operation.\n");
    while (1)
    {
        pthread_mutex_lock(&mospf_lock);
        log(DEBUG, "router [%x] checking database", instance->router_id);
        mospf_db_entry_t *lsus, *pre;
        list_for_each_entry_safe(lsus, pre, &mospf_db, list)
		{
			if (lsus->rid == instance->router_id) {
				continue;
			}
			if (time(NULL) - lsus->alive >= MOSPF_DATABASE_TIMEOUT)
			{
                log (INFO, "LSU %x timeout, remove it from the LSDB", lsus->rid);
				list_delete_entry(&lsus->list);
				free(lsus->array);
				free(lsus);
			}
		}
        update_rtable_from_lsu();
        pthread_mutex_unlock(&mospf_lock);
        sleep(5);
    }

	return NULL;
}

void handle_mospf_hello(iface_info_t *iface, const char *packet, int len)
{
    // fprintf(stdout, "TODO: handle mOSPF Hello message.\n");
    pthread_mutex_lock(&mospf_lock);
    log(DEBUG, "handle_mospf_hello called");
    struct iphdr *ip = packet_to_ip_hdr(packet);
    struct mospf_hdr *mospf = (struct mospf_hdr *)(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE);
    struct mospf_hello *hello = (struct mospf_hello *)((char *)mospf + MOSPF_HDR_SIZE);
    u32 nbr_id = ntohl(mospf->rid);
    u32 nbr_ip = ntohl(ip->saddr);
    u32 nbr_mask = ntohl(hello->mask);

    // 是否已经存在邻居
    int flag = 0;
    mospf_nbr_t *nbr;
    list_for_each_entry(nbr, &iface->nbr_list, list) {
        if (nbr->nbr_id == nbr_id) {
			nbr->alive = time(NULL);
			flag = 1;
			break;
        }
    }

    // 如果不存在邻居，则添加
    if (!flag)
    {
        log(DEBUG, "New neighbor found: %x", nbr_id);
        nbr = malloc(sizeof(mospf_nbr_t));
        if (nbr == NULL) {
            log(ERROR, "malloc failed");
            pthread_mutex_unlock(&mospf_lock);
            return;
        }
        iface->num_nbr++;
        list_add_tail(&nbr->list, &iface->nbr_list);
        nbr->nbr_id = nbr_id;
        nbr->nbr_ip = nbr_ip;
        nbr->nbr_mask = nbr_mask;
		nbr->alive = time(NULL);

        // 加入自己的LSU
        mospf_db_entry_t *self_lsu = NULL;
        list_for_each_entry(self_lsu, &mospf_db, list) {
            if (self_lsu->rid == instance->router_id) {
                int found = 0;
                for (int i = 0; i < self_lsu->nadv; i++)
                    if (((self_lsu->array[i].network & self_lsu->array[i].mask) == (nbr->nbr_ip & nbr->nbr_mask)) && (self_lsu->array[i].rid != instance->router_id))
                    {
                        // 如果LSU中已经存在该邻居，则不添加
                        found = 1;
                        self_lsu->array[i].rid = nbr_id;
                        self_lsu->array[i].network = nbr_ip;
                        self_lsu->array[i].mask = nbr_mask;
                        break;
                    }
                if (!found) {
                    // 如果LSU中不存在该邻居，则添加
                    int nadv = self_lsu->nadv++;
                    struct mospf_lsa *lsa = self_lsu->array + nadv;
                    lsa->network = nbr_ip;
                    lsa->mask = nbr_mask;
                    lsa->rid = nbr_id;
                }
            }
        }
    }

    update_rtable_from_lsu();
    mospf_send_lsu(0);
    pthread_mutex_unlock(&mospf_lock);
}

void *sending_mospf_lsu_thread(void *param)
{
	// fprintf(stdout, "TODO: send mOSPF LSU message periodically.\n");
    while (1)
    {
        pthread_mutex_lock(&mospf_lock);
        log(DEBUG, "router [%x] begin to send LSU！！！！！", instance->router_id);
        mospf_send_lsu(0);
        pthread_mutex_unlock(&mospf_lock);
        sleep(6);
        // sleep(instance->lsuint);
    }   
	return NULL;
}

void handle_mospf_lsu(iface_info_t *iface, char *packet, int len)
{
	// fprintf(stdout, "TODO: handle mOSPF LSU message.\n");
    pthread_mutex_lock(&mospf_lock);
    // 首先在LSDB中查找是否存在该LSU
    struct mospf_hdr *mospf = (struct mospf_hdr *)(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE);
    if (ntohl(mospf->rid) == instance->router_id) {
        // 如果是自己的LSU，则忽略
        log(DEBUG, "Received my own LSU, ignoring.");
        pthread_mutex_unlock(&mospf_lock);
        return;
    }
    mospf_db_entry_t *lsu_in_lsdb = NULL;
    list_for_each_entry(lsu_in_lsdb, &mospf_db, list) {
        if (lsu_in_lsdb->rid == ntohl(mospf->rid)) {
            lsu_in_lsdb->alive = time(NULL);
            struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);
            if (ntohs(lsu->seq) > lsu_in_lsdb->seq) {
                // 更新LSDB中的LSU
                struct mospf_lsa *lsa = (struct mospf_lsa *)((char *)lsu + MOSPF_LSU_SIZE);
                lsu_in_lsdb->seq = ntohs(lsu->seq);
                lsu_in_lsdb->nadv = ntohl(lsu->nadv);
                for (int i = 0; i < ntohl(lsu->nadv); i++) {
                    lsu_in_lsdb->array[i].network = ntohl(lsa[i].network);
                    lsu_in_lsdb->array[i].mask = ntohl(lsa[i].mask);
                    lsu_in_lsdb->array[i].rid = ntohl(lsa[i].rid);
                }
                goto FORWARD; // 如果更新成功，则转发LSU
            }
            goto FINISH; // 如果存在，则直接结束
        }
    }

    // 如果不存在，则创建一个新的LSU
    mospf_db_entry_t *new_lsu = NULL;
    struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);
    new_lsu = malloc(sizeof(mospf_db_entry_t));
    if (new_lsu == NULL) {
        log(ERROR, "malloc failed");
        pthread_mutex_unlock(&mospf_lock);
        return;
    }
    list_add_tail(&new_lsu->list, &mospf_db);
    new_lsu->rid = ntohl(mospf->rid);
    new_lsu->seq = ntohs(lsu->seq);
    new_lsu->alive = time(NULL);
    new_lsu->nadv = ntohl(lsu->nadv);
    new_lsu->array = malloc(sizeof(struct mospf_lsa) * 8);
    if (new_lsu->array == NULL) {
        log(ERROR, "malloc failed");
        free(new_lsu);
        pthread_mutex_unlock(&mospf_lock);
        return;
    }

    update_rtable_from_lsu();
FORWARD:
    // 将该LSU转发
    iface_info_t *lsu_iface = NULL;
    list_for_each_entry(lsu_iface, &instance->iface_list, list)
    {
        mospf_nbr_t *nbr = NULL;
        list_for_each_entry(nbr, &lsu_iface->nbr_list, list) 
        {
            if (nbr->nbr_id == ntohl(mospf->rid)) 
            continue;
            char *lsu_packet = malloc(len);
            if (lsu_packet == NULL) {
                log(ERROR, "malloc failed");
                continue;
            }
            memcpy(lsu_packet, packet, len);
            struct iphdr *ip = packet_to_ip_hdr(lsu_packet);
            ip_init_hdr(ip, lsu_iface->ip, nbr->nbr_ip, len - ETHER_HDR_SIZE, IPPROTO_MOSPF);
            ip_send_packet(lsu_packet, len);
        }
    }
FINISH:
    pthread_mutex_unlock(&mospf_lock);
}

void handle_mospf_packet(iface_info_t *iface, char *packet, int len)
{
	struct iphdr *ip = (struct iphdr *)(packet + ETHER_HDR_SIZE);
	struct mospf_hdr *mospf = (struct mospf_hdr *)((char *)ip + IP_HDR_SIZE(ip));

	if (mospf->version != MOSPF_VERSION) {
		log(ERROR, "received mospf packet with incorrect version (%d)", mospf->version);
		return ;
	}
	if (mospf->checksum != mospf_checksum(mospf)) {
		log(ERROR, "received mospf packet with incorrect checksum");
		return ;
	}
	if (ntohl(mospf->aid) != instance->area_id) {
		log(ERROR, "received mospf packet with incorrect area id");
		return ;
	}

	switch (mospf->type) {
		case MOSPF_TYPE_HELLO:
			handle_mospf_hello(iface, packet, len);
			break;
		case MOSPF_TYPE_LSU:
			handle_mospf_lsu(iface, packet, len);
			break;
		default:
			log(ERROR, "received mospf packet with unknown type (%d).", mospf->type);
			break;
	}
}

void update_rtable_from_lsu()
{
    clear_rtable();
    
    // 第一步: 添加直连网络
    int direct_routes = 0;
    iface_info_t *if_item = NULL;
    list_for_each_entry(if_item, &instance->iface_list, list) {
        u32 network_addr = if_item->ip & if_item->mask;
        rt_entry_t *direct_route = new_rt_entry(
            network_addr,     // 网络地址
            if_item->mask,    // 子网掩码
            0,                // 直连网络无需网关
            if_item           // 出接口
        );
        add_rt_entry(direct_route);
        direct_routes++;
        
        log(DEBUG, "add direct route: " IP_FMT "/" IP_FMT " from interface %s",
            HOST_IP_FMT_STR(network_addr), HOST_IP_FMT_STR(if_item->mask), if_item->name);
    }
    
    // 第二步: 获取所有路由器ID
    u32 all_routers[MAX_ROUTER_NUM];
    int router_num = 0;
    u32 my_rid = instance->router_id;
    
    // 添加自己
    all_routers[router_num++] = my_rid;
    
    // 添加其他路由器
    mospf_db_entry_t *db_item = NULL;
    list_for_each_entry(db_item, &mospf_db, list) {
        if (db_item->rid != my_rid) {
            all_routers[router_num++] = db_item->rid;
        }
    }
    
    // 第三步: 构建拓扑图
    u32 topo_matrix[MAX_ROUTER_NUM][MAX_ROUTER_NUM];
    memset(topo_matrix, 0, sizeof(topo_matrix));
    
    // 填充拓扑图
    list_for_each_entry(db_item, &mospf_db, list) {
        // 找出源路由器索引
        int src_pos = -1;
        for (int idx = 0; idx < router_num; idx++) {
            if (all_routers[idx] == db_item->rid) {
                src_pos = idx;
                break;
            }
        }
        
        if (src_pos == -1) continue;
        
        // 处理每个邻居
        for (int j = 0; j < db_item->nadv; j++) {
            // 只处理路由器间连接
            if (db_item->array[j].rid != 0) {
                // 找出目标路由器索引
                int dst_pos = -1;
                for (int k = 0; k < router_num; k++) {
                    if (all_routers[k] == db_item->array[j].rid) {
                        dst_pos = k;
                        break;
                    }
                }
                
                if (dst_pos != -1) {
                    // 建立双向连接
                    topo_matrix[src_pos][dst_pos] = 1;
                    topo_matrix[dst_pos][src_pos] = 1;
                }
            }
        }
    }
    
    // 第四步: Dijkstra算法计算最短路径
    int distances[MAX_ROUTER_NUM];
    int previous[MAX_ROUTER_NUM];
    int processed[MAX_ROUTER_NUM];
    
    // 初始化距离和前驱数组
    for (int i = 0; i < router_num; i++) {
        distances[i] = 0x7fffffff;
        previous[i] = -1;
        processed[i] = 0;
    }
    
    // 找出自己在路由器数组中的位置
    int self_pos = -1;
    for (int i = 0; i < router_num; i++) {
        if (all_routers[i] == my_rid) {
            self_pos = i;
            break;
        }
    }
    
    // 从自己开始搜索
    distances[self_pos] = 0;
    
    // Dijkstra核心算法
    for (int count = 0; count < router_num; count++) {
        // 找出未处理节点中距离最小的
        int shortest = 0x7fffffff;
        int current_node = -1;
        
        for (int v = 0; v < router_num; v++) {
            if (!processed[v] && distances[v] < shortest) {
                shortest = distances[v];
                current_node = v;
            }
        }
        
        if (current_node == -1) break;
        
        processed[current_node] = 1;
        
        // 更新邻居节点的距离
        for (int v = 0; v < router_num; v++) {
            if (!processed[v] && topo_matrix[current_node][v] && 
                distances[current_node] != 0x7fffffff &&
                distances[current_node] + 1 < distances[v]) {
                distances[v] = distances[current_node] + 1;
                previous[v] = current_node;
            }
        }
    }
    
    // 第五步: 为每个目的网络创建路由表条目
    for (int dest_idx = 0; dest_idx < router_num; dest_idx++) {
        // 跳过自己或不可达路由器
        if (dest_idx == self_pos || previous[dest_idx] == -1) continue;
        
        u32 target_router_id = all_routers[dest_idx];
        
        // 查找该路由器的数据库条目
        mospf_db_entry_t *target_entry = NULL;
        list_for_each_entry(target_entry, &mospf_db, list) {
            if (target_entry->rid == target_router_id) {
                // 处理该路由器通告的每个网络
                for (int nw = 0; nw < target_entry->nadv; nw++) {
                    // 跳过与其他路由器的连接
                    if (target_entry->array[nw].rid != 0) continue;
                    
                    u32 target_network = target_entry->array[nw].network;
                    u32 target_mask = target_entry->array[nw].mask;
                    
                    // 计算下一跳路由器
                    int next_hop_idx = dest_idx;
                    
                    // 从目标路由器开始回溯到直接与自己相连的路由器
                    while (previous[next_hop_idx] != self_pos && previous[next_hop_idx] != -1) {
                        next_hop_idx = previous[next_hop_idx];
                    }
                    
                    // 确保找到了有效的下一跳
                    if (previous[next_hop_idx] == self_pos) {
                        u32 next_hop_router_id = all_routers[next_hop_idx];
                        
                        // 查找通往下一跳的接口和IP
                        iface_info_t *outgoing_if = NULL;
                        u32 gateway_ip = 0;
                        int found_interface = 0;
                        
                        // 遍历所有接口找到通往下一跳的接口
                        list_for_each_entry(if_item, &instance->iface_list, list) {
                            // 在接口的邻居列表中查找
                            mospf_nbr_t *nbr_item = NULL;
                            list_for_each_entry(nbr_item, &if_item->nbr_list, list) {
                                if (nbr_item->nbr_id == next_hop_router_id) {
                                    outgoing_if = if_item;
                                    gateway_ip = nbr_item->nbr_ip;
                                    found_interface = 1;
                                    break;
                                }
                            }
                            if (found_interface) break;
                        }
                        
                        // 创建路由表条目
                        if (found_interface) {
                            rt_entry_t *new_route = new_rt_entry(
                                target_network,
                                target_mask,
                                gateway_ip,
                                outgoing_if
                            );
                            
                            add_rt_entry(new_route);
                            
                            log(INFO, "add route: " IP_FMT "/" IP_FMT " gw " IP_FMT " interface %s",
                                HOST_IP_FMT_STR(target_network), HOST_IP_FMT_STR(target_mask),
                                HOST_IP_FMT_STR(gateway_ip), outgoing_if->name);
                        }
                    }
                }
                break;
            }
        }
    }
    mprint_lsdb();
    mprint_rtable();
}

// 将LSU发送到所有邻居
// 这里的LSU是指本地的LSU，即自己的LSU
void mospf_send_lsu(u32 avoid_nbr_id)
{
    // 首先找到自己的LSU
    mospf_db_entry_t *self_lsu = NULL;
    list_for_each_entry(self_lsu, &mospf_db, list) {
        if (self_lsu->rid == instance->router_id) {
            // 准备发送的LSU包
            int len = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + MOSPF_HDR_SIZE + MOSPF_LSU_SIZE + self_lsu->nadv * MOSPF_LSA_SIZE;
            char *packet = malloc(len);
            if (packet == NULL) {
                log(ERROR, "malloc failed");
                return;
            }
            struct mospf_hdr *mospf = (struct mospf_hdr *)(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE);
            mospf_init_hdr(mospf, MOSPF_TYPE_LSU, MOSPF_HDR_SIZE + MOSPF_LSU_SIZE + self_lsu->nadv * MOSPF_LSA_SIZE,
                           instance->router_id, instance->area_id);
            struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);
            mospf_init_lsu(lsu, self_lsu->nadv);
            instance->sequence_num++;

            // 填充LSA
            struct mospf_lsa *lsas = (struct mospf_lsa *)((char *)lsu + MOSPF_LSU_SIZE);
            for (int i = 0; i < self_lsu->nadv; i++) {
                lsas[i].network = htonl(self_lsu->array[i].network);
                lsas[i].mask = htonl(self_lsu->array[i].mask);
                lsas[i].rid = htonl(self_lsu->array[i].rid);
            }
            mospf->checksum = mospf_checksum(mospf);

            // 发送LSU
            iface_info_t *iface = NULL;
            list_for_each_entry(iface, &instance->iface_list, list)
            {
                mospf_nbr_t *nbr = NULL;
                list_for_each_entry(nbr, &iface->nbr_list, list)
                {
                    if (nbr->nbr_id == avoid_nbr_id) {
                        // 如果是要避免的邻居，则跳过
                        continue;
                    }
                    char *temp_packet = malloc(len);
                    if (temp_packet == NULL) {
                        log(ERROR, "malloc failed");
                        free(packet);
                        return;
                    }
                    memcpy(temp_packet, packet, len);
                    struct ether_header *eh = packet_to_ether_hdr(temp_packet);
                    struct iphdr *ip = packet_to_ip_hdr(temp_packet);
                    ip_init_hdr(ip, iface->ip, nbr->nbr_ip, len - ETHER_HDR_SIZE, IPPROTO_MOSPF);
                    ip_send_packet(temp_packet, len);
                }
            }

            free(packet);
            break; // 只需要发送自己的LSU一次
        }
    }
    mprint_lsdb();
    mprint_rtable();
}