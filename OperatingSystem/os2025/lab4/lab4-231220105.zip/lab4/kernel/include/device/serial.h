#ifndef __SERIAL_H__
#define __SERIAL_H__

void initSerial(void);
void putChar(char);
void putStr(char *str);
void putNum(int num);

#endif
